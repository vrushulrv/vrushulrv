﻿using Campain.Models.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Campaign.BusinessService.IBusinessService
{
    public interface ICampaignBusinessService
    {
        Task<List<CampaignData>> GetAllCampaigns();

        Task<List<CampaignData>> GetActiveCampaigns();
        Task<List<CampaignData>> GetClosedCampaigns();
    }
}
