﻿using Campaign.BusinessService.IBusinessService;
using Campaign.Services.IServcies;
using Campain.Models.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Campaign.BusinessService.BusinessService
{
    public class CampaignBusinessService : ICampaignBusinessService
    {
        private ICampaignService _campaignService;
        public CampaignBusinessService(ICampaignService campaignService)
        {
            _campaignService = campaignService;
        }

        public async Task<List<CampaignData>> GetActiveCampaigns()
        {
            return await _campaignService.GetActiveCampaigns();
        }

        public async Task<List<CampaignData>> GetAllCampaigns()
        {
            return await _campaignService.GetAllCampaigns();
        }

        public async Task<List<CampaignData>> GetClosedCampaigns()
        {
            return await _campaignService.GetClosedCampaigns();
        }
    }
}
