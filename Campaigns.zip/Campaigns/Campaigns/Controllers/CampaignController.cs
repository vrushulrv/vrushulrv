﻿using Campaign.BusinessService.IBusinessService;
using Campain.Models.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace Campaigns.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CampaignController : ControllerBase
    {
        private ICampaignBusinessService _campaignBusinessService;

        private readonly ILogger<CampaignController> _logger;

        public CampaignController(ILogger<CampaignController> logger, ICampaignBusinessService campaignBusinessService)
        {
            _logger = logger;
            _campaignBusinessService = campaignBusinessService;
        }

        [HttpGet]
        [Route("AllCampaigns")]
        public async Task<ActionResult<CampaignData>> GetAllCampaigns()
        {
            try
            {
                var campaignList = await _campaignBusinessService.GetAllCampaigns();
                return Ok(campaignList);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to process the request.");
                return new StatusCodeResult(500);
            }
        }

        [HttpGet]
        [Route("ActiveCampaigns")]
        public async Task<ActionResult<CampaignData>> GetActiveCampaigns()
        {
            try
            {
                var campaignList = await _campaignBusinessService.GetActiveCampaigns();
                return Ok(campaignList);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to process the request.");
                return new StatusCodeResult(500);
            }
        }

        [HttpGet]
        [Route("ClosedCampaigns")]
        public async Task<ActionResult<CampaignData>> GetClosedCampaigns()
        {
            try
            {
                var campaignList = await _campaignBusinessService.GetClosedCampaigns();
                return Ok(campaignList);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unable to process the request.");
                return new StatusCodeResult(500);
            }
        }
    }
}
