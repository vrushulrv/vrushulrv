﻿using Campaign.Services.IServcies;
using Campain.Models.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Campaign.Services.Services
{
    public class CampaignService : ICampaignService
    {
        public async Task<List<CampaignData>> GetActiveCampaigns()
        {
            List<CampaignData> campaignList = await GetCampaign();
            var response = campaignList.Where(x => x.EndDate >= DateTime.Today && x.Created >= DateTime.Now.AddDays(-30)).ToList();
            return response;
        }

        public async Task<List<CampaignData>> GetAllCampaigns()
        {
            List<CampaignData> campaignList = await GetCampaign();
            var response = campaignList.OrderByDescending(x => x.TotalAmount).ToList();
            return response;
        }

        public async Task<List<CampaignData>> GetClosedCampaigns()
        {
            List<CampaignData> campaignList = await GetCampaign();
            var response = campaignList.Where(x => x.EndDate < DateTime.Today || x.ProcuredAmount >= x.TotalAmount).ToList();

            return response;
        }

        private static async Task<List<CampaignData>> GetCampaign()
        {
            List<CampaignData> campaignList = new List<CampaignData>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://testapi.donatekart.com/api/campaign"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    campaignList = JsonConvert.DeserializeObject<List<CampaignData>>(apiResponse);
                }
            }

            return campaignList;
        }
    }
}
