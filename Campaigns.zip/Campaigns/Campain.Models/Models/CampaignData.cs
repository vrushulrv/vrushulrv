﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Campain.Models.Models
{
    public class CampaignData
    {
        public string Title { get; set; }

        public decimal TotalAmount { get; set; }

        public decimal BackersCount { get; set; }
        public decimal ProcuredAmount { get; set; }


        public DateTime Created { get; set; }
        public DateTime EndDate { get; set; }
        public int daysLeft { get; set; }
    }
}
