import React, { Component } from "react";
import { connect } from "react-redux";
import Select from "react-select";
import { addToCart, changeCurrency } from "./actions/cartActions";

class Home extends Component {
  state = {
    currencySymbol: 'Rs',
  };
  handleClick = (id) => {
    this.props.addToCart(id);
  };

  handleSelect = (val) => {
    this.props.changeCurrency(val);
    if(val==='USD')
    this.setState({currencySymbol: '$'});
    else if(val==='INR')
    this.setState({currencySymbol: 'Rs'});
    this.forceUpdate();
    console.log(val);
  };

  render() {
  
    let itemList = this.props.items.map((item) => {
      return (
        <div className="card" key={item.id}>
          <div className="card-image">
            <img src={item.img} alt={item.title} />
            <span className="card-title">{item.title}</span>
            <span
              to="/"
              className="btn-floating halfway-fab waves-effect waves-light red"
              onClick={() => {
                this.handleClick(item.id);
              }}
            >
              <i className="material-icons add-product">add</i>
            </span>
          </div>

          <div className="card-content">
            <p>{item.desc}</p>
            <p>
              <b>Price: {item.price}{this.state.currencySymbol}</b>
            </p>
          </div>
        </div>
      );
    });

    return (
      <div className="container">
        <h3 className="center">Our items</h3>
        <div>
          Currency :
          <select
            className="drpdwn"
            name="selectList"
            id="selectList"
            onChange={(e) => this.handleSelect(e.target.value)}
          >
            <option value="INR">INR</option>
            <option value="USD">USD</option>
          </select>
        </div>
        <div className="box">{itemList}</div>
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    items: state.items,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    addToCart: (id) => {
      dispatch(addToCart(id));
    },
    changeCurrency: (val) => {
      dispatch(changeCurrency(val));
    },
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
